# sky-force-clone
Making a clone of the game sky-force using webGl and other 3D libraries
